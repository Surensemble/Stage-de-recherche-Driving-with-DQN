
import numpy as np
import random
from collections import namedtuple
import torch.nn as nn
import torch.optim as optim
import torch
import torch.nn.functional as F
from collections import namedtuple

 
from itertools import count
from vehicle import Driver
from controller import Camera, Lidar

########################################################################
#============================== fichier 1==============================#
########################################################################

experience = namedtuple("experience",('state','action','next_state','reward','done'))

class ExperienceReplay():
    def __init__(self,capacity):
        self.capacity = capacity
        self.memory = []
        self.position = 0

    def add(self,*args):
        if len(self.memory)<self.capacity:
            self.memory.append(None)
        self.memory[self.position] = experience(*args)
        #circular queue kinda thing, old transitions will get replaced
        self.position = (self.position+1)%self.capacity
    def sample(self,batch_size):
        return random.sample(self.memory,batch_size)
    def __len__(self):
        return len(self.memory)
        
        

########################################################################
#============================== Deep Q network=========================#
########################################################################


class DQN(nn.Module):
    def __init__(self,frame_history_len,height_image,width_image,n_actions,lr):
        super(DQN,self).__init__()
        self.frame_history_len = frame_history_len
        self.conv1 = nn.Conv2d(self.frame_history_len,32,5)   # 4 images, 32 out channels, 5*5 krnel default stride=1
        self.conv2 = nn.Conv2d(32,64,5)
        self.conv3 = nn.Conv2d(64,128,5)


        x = torch.randn(self.frame_history_len,height_image,width_image).view(-1,frame_history_len,height_image,width_image)
        #print("Expected dimensions of input- ")
        #print(x.size())
        self.to_linear = None   #auxillary variable to calculate shape of output of conv+max_pool
        self.convs(x)

        self.fc1 = nn.Linear(self.to_linear,512)
        self.fc2 = nn.Linear(512,256)
        self.fc3 = nn.Linear(256,n_actions)
        self.lr = lr
        self.optimizer = optim.Adam(self.parameters(),lr = self.lr)

    def convs(self,x):

        x = F.max_pool2d(F.relu(self.conv1(x)),(2,2))
        x = F.max_pool2d(F.relu(self.conv2(x)),(2,2))
        x = F.max_pool2d(F.relu(self.conv3(x)),(2,2))
        #x = self.model(x)
        if self.to_linear is None:
            self.to_linear = x[0].shape[0]*x[0].shape[1]*x[0].shape[2]
        return x
    def forward(self,x):
        x = self.convs(x)
        x = x.view(-1,self.to_linear)   #flattening
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        x = self.fc3(x)
        return x
        
        
########################################################################
#============================== fichier 3===============================#
########################################################################
driver = Driver()
camera = driver.getDevice("camera")
lidar = driver.getDevice("lidar")
camera.enable(50)
lidar.enable(50)

lidar.enablePointCloud() 

# Adapter l'interface pour Webots
class WebotsEnv:
    def __init__(self):
        self.driver = driver
        self.camera = camera
        self.lidar = lidar
        self.camera.enable(50)
        self.lidar.enable(50)

    def reset(self):
        # Réinitialiser le simulateur Webots
        #self.driver.simulationReset()
        self.driver.simulationResetPhysics()
        #self.driver.start()
        return self.get_observation()

    def step(self, action):
        accel, steer = action
        self.driver.setCruisingSpeed(accel)
        self.driver.setSteeringAngle(steer)
        self.driver.step(50)
        next_state = self.get_observation()
        reward, done, info = self.compute_reward(next_state)
        return next_state, reward, done, info

    def get_observation(self):
        camera_data = self.camera.getImage()
        lidar_data = self.lidar.getPointCloud()
        return {'camera': camera_data, 'lidar': lidar_data}

    def compute_reward(self, observation):
        # Implémenter une fonction de récompense basée sur l'état
        reward = 0
        done = False
        info = {}
        return reward, done, info


def test(env, n_episodes, policy, device, render=False):
    for episode in range(n_episodes):
        obs = env.reset()
        #state1 = torchify_state_dim(obs['camera'])
        state1 = np.array(camera.getImageArray())
        state1 = state1.transpose((2, 0, 1))
        state1 = torch.from_numpy(state1).float()
        #return state.unsqueeze(0)
        #state2 = torchify_state_dim(obs['lidar'])
        state2 = np.array(lidar.getRangeImage())
        state2 = state2.reshape(180, 1, 1)
        new_state2 = torch.zeros(180, 180, 3)
        state2[:, :, :] = state2
        state2 = state2.transpose((2, 0, 1))
        state2 = torch.from_numpy(state2).float()
        
        state = torch.cat((state1, state2)).view(1, 4, 168, 84)
        total_reward = 0.0
        for t in count():
            action = policy(state.to(device)).max(1)[1].view(1, 1)
            action_ = map_action(action)
            next_state, reward, done, info = env.step(action_)
            next_state1 = next_state['camera']
            next_state2 = next_state['lidar']
            total_reward += reward
            if done:
                next_state = torch.zeros(state.size())
                done_flag = 1
            else:
                next_state1 = torchify_state_dim(next_state1)
                next_state2 = torchify_state_dim(next_state2)
                next_state = torch.cat((next_state1, next_state2)).view(1, 4, 168, 84)
                done_flag = 0
            state = next_state
            if done:
                print(f"Finished Episode {episode} with reward {total_reward}")
                break
    env.close()
    return

def map_action(action):
    if action == 0:
        return [-3.0, 0]
    elif action == 1:
        return [-1.0, 0]
    elif action == 2:
        return [0.5, 0]
    elif action == 3:
        return [2.0, 0.0]
    elif action == 4:
        return [3.0, 0.0]
    elif action == 5:
        return [0.20, -0.3]
    elif action == 6:
        return [0.25, -0.2]
    elif action == 7:
        return [0.35, -0.1]
    elif action == 8:
        return [0.35, 0.1]
    elif action == 9:
        return [0.25, 0.2]
    elif action == 10:
        return [0.20, 0.3]

if __name__ == '__main__':
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    env = WebotsEnv()
    agent = torch.load("final_saved_model")
    test(env, 5, agent, device)




########################################################################
#============================== Agent =================================#
########################################################################
 

class Agent():
    def __init__(self, action_space, frame_history_len, env, device, buffer_size, epsilon_start, epsilon_decay, epsilon_min, update_every, batch_size):
        self.action_space = action_space
        self.frame_history_len = frame_history_len
        self.env = env
        self.device = device
        self.policy_qnet = DQN(self.frame_history_len, 168, 84, 11, 1e-4).to(self.device)
        self.target_qnet = DQN(self.frame_history_len, 168, 84, 11, 1e-4).to(self.device)
        self.target_qnet.load_state_dict(self.policy_qnet.state_dict())
        self.optimizer = self.policy_qnet.optimizer
        self.epsilon_start = epsilon_start
        self.epsilon_decay = epsilon_decay
        self.epsilon_min = epsilon_min
        self.batch_size = batch_size
        self.buffer = ExperienceReplay(buffer_size)
        self.update_every = update_every

    def epsilon_greedy_act(self, state, eps=0.0):
        rnd = random.random()
        if rnd < eps:
            return np.random.randint(self.action_space)
        else:
            self.policy_qnet.eval()
            with torch.no_grad():
                action_values = self.policy_qnet(state.to(self.device))
            action = np.argmax(action_values.cpu().data.numpy())
            self.policy_qnet.train()
            return action

    def torchify_state_dim(self, obs):
        state = np.array(obs)
        state = state.transpose((2, 0, 1))
        state = torch.from_numpy(state).float()
        return state.unsqueeze(0)

    def update_gradients(self):
        gamma = 0.99
        if self.buffer.__len__() < self.batch_size:
            return
        batch = self.buffer.sample(self.batch_size)
        experience = namedtuple('experience', ('state', 'action', 'next_state', 'reward', 'done'))
        batch = experience(*zip(*batch))
        states = torch.cat(batch.state).to(self.device)
        actions = torch.cat(batch.action).to(self.device)
        rewards = torch.cat(batch.reward).to(self.device)
        next_states = torch.cat(batch.next_state).to(self.device)
        dones = torch.cat(batch.done).to(self.device)
        action_values = self.target_qnet(next_states).detach()
        max_action_values = action_values.max(1)[0].detach()
        target = rewards + gamma * max_action_values * (1 - dones)
        current = self.policy_qnet(states).gather(1, actions)
        target = target.reshape(self.batch_size, 1)
        loss = F.smooth_l1_loss(target, current)
        self.optimizer.zero_grad()
        loss.backward()
        for param in self.policy_qnet.parameters():
            param.grad.data.clamp_(-1.2, 1.2)
        self.optimizer.step()

    def train(self, max_episodes):
        global steps
        reward_track = []
        eps = self.epsilon_start
        for episode in tqdm(range(max_episodes)):
            obs = self.env.reset()
            state1 = self.torchify_state_dim(obs['camera'])
            state2 = self.torchify_state_dim(obs['lidar'])
            state = torch.cat((state1, state2)).view(1, 4, 168, 84)
            total_reward = 0
            for t in range(10000):
                action = self.epsilon_greedy_act(state, eps)
                action_ = map_action(action)
                next_state, reward, done, _ = self.env.step(action_)
                next_state1 = next_state['camera']
                next_state2 = next_state['lidar']
                if done:
                    next_state = torch.zeros(state.size())
                    done_flag = 1
                else:
                    next_state1 = self.torchify_state_dim(next_state1)
                    next_state2 = self.torchify_state_dim(next_state2)
                    next_state = torch.cat((next_state1, next_state2)).view(1, 4, 168, 84)
                    done_flag = 0
                reward = torch.tensor([reward], device=self.device)
                done_flag = torch.tensor([done_flag], device=self.device)
                action = torch.tensor([[action]], device=self.device)
                self.buffer.push(state, action, next_state, reward, done_flag)
                state = next_state
                self.update_gradients()
                steps += 1
                if steps % self.update_every == 0:
                    self.target_qnet.load_state_dict(self.policy_qnet.state_dict())
                if done:
                    break
            eps = max(self.epsilon_min, eps * self.epsilon_decay)
            reward_track.append(total_reward)
            if episode % 100 == 0:
                torch.save(self.policy_qnet, 'saved_model')
        return reward_track

        
                    
                
    